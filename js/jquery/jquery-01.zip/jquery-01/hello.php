<html>
<head>
</head>
<body>
<p>Here is some awesome page content</p>
<script type="text/javascript" src="jquery.min.js">
</script>
<script type="text/javascript">
$(document).ready(function(){ 
  alert("Hello JQuery World!"); 
  window.console && console.log('Hello JQuery..');
});
</script>
</body>
